<script>
  let { children } = $props();
  import "../app.css";



</script>
{@render children()}