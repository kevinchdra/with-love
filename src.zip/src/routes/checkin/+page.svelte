<script>
  import { onMount } from 'svelte';
  import { Html5Qrcode } from 'html5-qrcode';
  import { fade } from 'svelte/transition';
  import { goto } from '$app/navigation';

  let scanned = false;
  let guestName = '';
  let numberOfGuests = 1;
  let printQR = false;
  let checkInConfirmed = false;
  let errorMessage = '';

  function onScanSuccess(decodedText) {
    console.log("QR Code detected:", decodedText);
    guestName = decodedText; // Replace with actual parsing logic if needed
    scanned = true;
  }

  function onScanFailure(error) {
    // Optional: console.warn(`QR scan failed: ${error}`);
  }

  function confirmCheckIn() {
    checkInConfirmed = true;
    setTimeout(() => {
      scanned = false;
      checkInConfirmed = false;
      goto('/');
    }, 2000);
  }

  onMount(() => {
    const qrRegionId = "reader";
    const html5QrCode = new Html5Qrcode(qrRegionId);

    Html5Qrcode.getCameras().then(cameras => {
      if (cameras && cameras.length) {
        html5QrCode.start(
          { facingMode: "environment" },
          {
            fps: 10,
            qrbox: 250
          },
          onScanSuccess,
          onScanFailure
        );
      } else {
        errorMessage = "No camera found";
      }
    }).catch(err => {
      errorMessage = "Camera access error: " + err;
    });
  });
</script>

<style>
  .pink-bg {
    background: linear-gradient(to bottom, #f9c2cf, #dd748a);
  }
</style>

{#if !scanned}
  <div class="flex h-screen">
    <div class="w-1/2 pink-bg flex items-center justify-center">
      <h1 class="text-white text-4xl font-light">Vanessa & Eddy</h1>
    </div>

    <div class="w-1/2 flex flex-col items-center justify-center space-y-4">
      <p class="text-sm">SCAN QR</p>
      {#if errorMessage}
        <p class="text-red-600">{errorMessage}</p>
      {:else}
        <div id="reader" class="w-[300px] h-[300px] border rounded shadow-md"></div>
      {/if}
    </div>
  </div>
{:else}
  <div class="min-h-screen p-8 space-y-10">
    <h2 class="text-2xl">Welcome, {guestName}</h2>

    <div transition:fade>
      <label class="block mb-2 font-medium">Number of guests</label>
      <div class="flex items-center space-x-2">
        <button class="border px-3" on:click={() => numberOfGuests = Math.max(1, numberOfGuests - 1)}>-</button>
        <span>{numberOfGuests}</span>
        <button class="border px-3" on:click={() => numberOfGuests++}>+</button>
      </div>
    </div>

    <div transition:fade>
      <label class="block mb-2 font-medium">Print QR Code?</label>
      <div class="flex space-x-4">
        <button class="border px-4 py-1" on:click={() => printQR = true}>Yes</button>
        <button class="border px-4 py-1" on:click={() => printQR = false}>No</button>
      </div>
    </div>

    {#if printQR}
      <div class="mt-4 transition-opacity duration-500" transition:fade>
        <p class="mb-2 font-medium">Gift QR Code</p>
        <img src="/qrcode-placeholder.png" alt="QR Code" class="w-40 h-40" />
        <p class="text-sm mt-2">TYPE OF GIFT: ANGPAO</p>
      </div>
    {/if}

    <div transition:fade>
      <label class="block mb-2 font-medium">Checked-in?</label>
      <div class="space-x-4">
        <button class="border px-6 py-2" on:click={confirmCheckIn}>Yes</button>
        <button class="border px-6 py-2">No</button>
      </div>
    </div>

    {#if checkInConfirmed}
      <p class="text-green-600 font-semibold mt-6">Check-in Successful</p>
    {/if}
  </div>
{/if}
